


// function generateResponsePayload(transaction, updatedBalance, userId, firstName, middleName) {
//     return {
//       transaction,
//       balance: updatedBalance,
//       user: {
//         id: userId,
//         firstName,
//         middleName,
//       },
//     };
//   }

//   module.exports = {
//     generateResponsePayload,
//   };